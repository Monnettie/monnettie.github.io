/**
 * LevelParser - Handles parsing text-based level definitions into game entities
 */
export class LevelParser {
    constructor() {
        this.tileSize = 50;
    }

    /**
     * Parse a level string into entity data
     * @param {string} levelString - Text representation of the level
     * @param {Array} customMessages - Array of custom messages for message tiles
     * @param {Object} decalSource - Source coordinates for decal sprites {x, y, width, height}
     * @returns {Object} Parsed level data with entities
     */
    parseLevel(levelString, customMessages = [], decalSource = null, decalDestination = null) {
        // Clean the level string - remove tabs and spaces
        const lines = levelString.trim().split('\n').map(line => 
            line.replace(/\t/g, '').replace(/ /g, '')
        );

        const entities = {
            player: null,
            platforms: [],
            coins: [],
            enemies: [],
            messages: [],
            decals: []
        };

        // Parse each character in the level string
        lines.forEach((line, y) => {
            for (let x = 0; x < line.length; x++) {
                const char = line[x];
                const nextChar = x + 1 < line.length ? line[x + 1] : '';
                const worldX = x * this.tileSize;
                const worldY = y * this.tileSize;
                
                // Check for message tiles (M/m followed by number)
                if ((char === 'M' || char === 'm') && /^[0-9]$/.test(nextChar)) {
                    const messageIndex = parseInt(nextChar);
                    const message = customMessages[messageIndex] || `Message ${messageIndex}`;
                    
                    // Add solid platform tile only for uppercase M
                    if (char === 'M') {
                        entities.platforms.push({ 
                            x: worldX, y: worldY, 
                            width: this.tileSize * 2, height: this.tileSize,
                            collisionType: 'solid'
                        });
                    }
                    
                    // Add message overlay for both M and m
                    entities.messages.push({
                        x: worldX,
                        y: worldY,
                        width: this.tileSize * 2,
                        height: this.tileSize,
                        text: message,
                        messageIndex: messageIndex
                    });
                    
                    // Skip the next character since we processed both M and the number
                    x++;
                    continue;
                }
                
                switch(char) {
                    case 'P':
                        entities.player = { x: worldX, y: worldY };
                        break;
                    case '#':
                        entities.platforms.push({ 
                            x: worldX, y: worldY, 
                            width: this.tileSize, height: this.tileSize ,
                            collisionType: 'solid'
                        });
                        break;
                    case 'C':
                        entities.coins.push({ x: worldX, y: worldY });
                        break;
                    case 'E':
                        entities.enemies.push({ x: worldX, y: worldY });
                        break;
                    case '^':
                        entities.platforms.push({ 
                            x: worldX, y: worldY, 
                            width: this.tileSize, height: this.tileSize,
                            collisionType: 'one-way-up'
                        });
                        break;
                    case 'v':
                        entities.platforms.push({ 
                            x: worldX, y: worldY, 
                            width: this.tileSize, height: this.tileSize,
                            collisionType: 'one-way-down'
                        });
                        break;
                    case '<':
                        entities.platforms.push({ 
                            x: worldX, y: worldY, 
                            width: this.tileSize, height: this.tileSize,
                            collisionType: 'one-way-left'
                        });
                        break;
                    case '>':
                        entities.platforms.push({ 
                            x: worldX, y: worldY, 
                            width: this.tileSize, height: this.tileSize,
                            collisionType: 'one-way-right'
                        });
                        break;
                    case 'x':
                        // Decal tile - purely decorative, no collision
                        // Calculate dimensions based on decalDestination or default to single tile
                        const decalWidth = decalDestination ? 
                            decalDestination.widthInTiles * this.tileSize : this.tileSize;
                        const decalHeight = decalDestination ? 
                            decalDestination.heightInTiles * this.tileSize : this.tileSize;
                        
                        entities.decals.push({
                            x: worldX,
                            y: worldY,
                            width: decalWidth,
                            height: decalHeight,
                            decalSource: decalSource,
                            decalDestination: decalDestination
                        });
                        break;
                    default:
                        // Check if it's a numbered platform (1-9)
                        if (/^[1-9]$/.test(char)) {
                            entities.platforms.push({ 
                                x: worldX, y: worldY, 
                                width: this.tileSize, height: this.tileSize,
                                collisionType: 'numbered',
                                requiredCoins: parseInt(char)
                            });
                        }
                        break;
                }
            }
        });

        // Merge adjacent platforms for better performance
        entities.platforms = this.mergePlatforms(entities.platforms);

        return entities;
    }

    /**
     * Merge adjacent platforms to reduce the number of collision objects
     * @param {Array} platforms - Array of platform objects
     * @returns {Array} Array of merged platform objects
     */
    mergePlatforms(platforms) {
        // First, merge horizontally adjacent platforms
        const horizontallyMerged = this.mergeHorizontalPlatforms(platforms);
        
        // Then, merge vertically adjacent platforms
        const fullyMerged = this.mergeVerticalPlatforms(horizontallyMerged);
        
        return fullyMerged;
    }

    /**
     * Merge horizontally adjacent platforms
     * @param {Array} platforms - Array of platform objects
     * @returns {Array} Array of horizontally merged platforms
     */
    mergeHorizontalPlatforms(platforms) {
        const mergedPlatforms = [];
        
        // Sort platforms by y, then x
        const sorted = platforms.slice().sort((a, b) => {
            if (a.y === b.y) return a.x - b.x;
            return a.y - b.y;
        });

        let i = 0;
        while (i < sorted.length) {
            let current = sorted[i];
            let merged = { ...current };
            let j = i + 1;
            
            // Merge consecutive platforms on the same row
            while (
                j < sorted.length &&
                sorted[j].y === current.y &&
                sorted[j].x === merged.x + merged.width &&
                sorted[j].collisionType === current.collisionType && // Only merge same collision types
                current.collisionType !== 'numbered' // Never merge numbered platforms
            ) {
                // Extend width
                merged.width += sorted[j].width;
                j++;
            }
            
            mergedPlatforms.push(merged);
            i = j;
        }
        
        return mergedPlatforms;
    }

    /**
     * Merge vertically adjacent platforms
     * @param {Array} platforms - Array of platform objects
     * @returns {Array} Array of vertically merged platforms
     */
    mergeVerticalPlatforms(platforms) {
        const verticallyMergedPlatforms = [];
        
        // Sort platforms by x, then y
        const vSorted = platforms.slice().sort((a, b) => {
            if (a.x === b.x) return a.y - b.y;
            return a.x - b.x;
        });

        let vi = 0;
        while (vi < vSorted.length) {
            let current = vSorted[vi];
            let merged = { ...current };
            let vj = vi + 1;
            
            // Merge consecutive platforms in the same column
            while (
                vj < vSorted.length &&
                vSorted[vj].x === current.x &&
                vSorted[vj].width === current.width && // Must have same width
                vSorted[vj].y === merged.y + merged.height &&
                vSorted[vj].collisionType === current.collisionType && // Only merge same collision types
                current.collisionType !== 'numbered' // Never merge numbered platforms
            ) {
                // Extend height
                merged.height += vSorted[vj].height;
                vj++;
            }
            
            verticallyMergedPlatforms.push(merged);
            vi = vj;
        }
        
        return verticallyMergedPlatforms;
    }

    /**
     * Get the default level string
     * @returns {string} Default level layout
     */
    getDefaultLevel() {
        return `
                               ###########################################
                               ###########################################
                               ##.......................................##
                               ##.......................................##
                               ##.......................................##
                               ##.......................................##
                               ##................C..............C.......##
                               ##.......................................##
                               ##.........................###...........##
                               ##.........................###..........###
                               ##....#..................................##
                               ##...###.............................C...##
                               ##....#........C.....C.....C.............##
                               ##.......................................##
                               ##.........C......................#########
                               ##............###.................#########
                               ##................................##......
                               ##.......P........................##......
                               ####################################......
                               ####################################......
                                .........................................`;
    }
}
