import { Player } from './entities/Player.js';
import { Coin } from './entities/Coin.js';
import { Enemy } from './entities/Enemy.js';
import { Platform } from './entities/Platform.js';
import { FrozenClone } from './entities/FrozenClone.js';
import { Anchor } from './entities/Anchor.js';
import { CollisionEngine } from './CollisionEngine.js';
import { LevelParser } from './LevelParser.js';
import { LevelDefinitions } from './LevelDefinitions.js';
/**
 * Game Model - Manages the overall game state and entities
 */
export class GameModel {
    constructor() {
        this.canvasWidth = 800;
        this.canvasHeight = 600;
        
        // Viewport culling information
        this.viewport = {
            left: 0,
            right: this.canvasWidth,
            top: 0,
            bottom: this.canvasHeight,
            buffer: 150 // Extra pixels around visible area to handle partially visible entities
        };
        
        this.player = new Player();
        this.coins = [];
        this.totalCoins = 0; // Total coins in the level
        this.enemies = [];
        this.platforms = [];
        this.frozenClones = [];
        this.anchors = []; // Anchors for reference points (not collidable)
        this.messages = []; // Message tiles for displaying custom text
        this.decals = []; // Decorative tiles with no collision
        this.isGameRunning = true;
        
        // Game states: 'TITLE', 'PLAYING', 'END'
        this.gameState = 'TITLE';
        
        this.collisionEngine = new CollisionEngine();
        this.score = 0;
        this.levelParser = new LevelParser();
        this.levelDefinitions = new LevelDefinitions(this.levelParser);
        this.isLevelCompleting = false; // Flag to prevent multiple completion triggers
        
        // Multi-level system
        this.currentLevel = 1;
        
        // Store previous player position for trajectory-based collision detection
        this.previousPlayerPosition = { x: 0, y: 0 };
        
        // Sound effects
        this.sounds = {
            levelComplete: null,
            coin: null,
            jump: null,
            clone: null,
            destroyClone: null,
            restart: null
        }

        this.music ={
            main: null,
            intro: null,
        }
        this.musicPlaying = true; // Track music state
        
        // Level transition delays (in milliseconds)
        this.levelCompleteDelay = 250; // Delay before advancing to next level
        this.gameCompleteDelay = 2000; // Delay before restarting after all levels complete

        // Level reset animation
        this.levelResetAnimationIsPlaying = false;
        this.levelResetAnimationStartTime = 0;
        this.levelResetAnimationDuration = 400;
        // Place action cooldown
        this.placeCooldown = 0;
        this.placeCooldownTime = 1000; // 1 second in milliseconds
        
        // Statistics tracking
        this.stats = {
            frozenClonesPlaced: 0,
            frozenClonesDestroyed: 0,
            loopRestarts: 0,
            levelBackwards: 0
        };
    }

    /**
     * Initialize the game
     */
    init() {
        // Load the current level with collision handlers
        this.loadCurrentLevel(true);

        this.totalCoins = this.coins.length; // Set total coins for level completion tracking
        
        this.player.setOnJump(() => {
            this.sounds.jump?.play();
        });
    }

    /**
     * Load the current level
     * @param {boolean} setupHandlers - Whether to setup collision handlers (default: true)
     * @param {boolean} preserveClones - Whether to preserve existing frozen clones (default: false)
     */
    loadCurrentLevel(setupHandlers = true, forceClonePreservation = false) {
        const level = this.levelDefinitions.getLevel(this.currentLevel);
        // Check if clones should be preserved for this level transition
        const preserveClones = forceClonePreservation || level.preserveClonesFromPrevious;

        const levelString = level.levelString;
        if (!levelString) {
            console.error(`Level ${this.currentLevel} not found!`);
            return;
        }
        
        console.log(`Loading Level ${this.currentLevel}...`);
        this.loadLevel(levelString, setupHandlers, preserveClones, level.customMessages, level.decalSource, level.decalDestination);
    }

    /**
     * Load a level from a level string
     * @param {string} levelString - Optional level string, uses default if not provided
     * @param {boolean} setupHandlers - Whether to setup collision handlers (default: true)
     * @param {boolean} preserveClones - Whether to preserve existing frozen clones (default: false)
     * @param {Array} customMessages - Array of custom messages for message tiles (default: [])
     * @param {Object} decalSource - Source coordinates for decal sprites (default: null)
     * @param {Object} decalDestination - Destination size for decal sprites in tiles (default: null)
     */
    loadLevel(levelString = null, setupHandlers = true, preserveClones = false, customMessages = [], decalSource = null, decalDestination = null) {
        // Parse the level
        const entities = this.levelParser.parseLevel(
            levelString || this.levelParser.getDefaultLevel(),
            customMessages,
            decalSource,
            decalDestination
        );

        // Store existing clones if they should be preserved
        const existingClones = preserveClones ? [...this.frozenClones] : [];

        // Clear existing entities (this will clear clones unless we preserve them)
        this.clearLevel(preserveClones);

        // Create game entities from parsed data
        
        // Create platforms
        entities.platforms.forEach(p => {
            this.platforms.push(new Platform(p.x, p.y, p.width, p.height, p.collisionType, p.requiredCoins));
        });

        // Create coins
        entities.coins.forEach(c => {
            this.coins.push(new Coin(c.x, c.y));
        });

        // Create enemies
        entities.enemies.forEach(e => {
            this.enemies.push(new Enemy(e.x, e.y));
        });

        // Store message tiles (don't need to create entity objects, just store the data)
        this.messages = entities.messages || [];

        // Store decal tiles (don't need to create entity objects, just store the data)
        this.decals = entities.decals || [];

        // Set player position
        if (entities.player) {
            this.player.resetToPosition(entities.player.x, entities.player.y);
            
            // Create anchor above the player starting position
            const anchor = new Anchor(entities.player.x, entities.player.y - 50); // 50 pixels above player
            this.anchors.push(anchor);
        }

        // Register entities with collision engine
        
        // Player should already be registered, but re-register to be safe
        this.collisionEngine.register(this.player);
        
        for (const coin of this.coins) {
            this.collisionEngine.register(coin);
        }
        
        for (const enemy of this.enemies) {
            this.collisionEngine.register(enemy);
        }
        
        for (const platform of this.platforms) {
            this.collisionEngine.register(platform);
        }

        // Setup collision handlers only if requested (avoid duplicate handlers on reset)
        if (setupHandlers) {
            this.collisionEngine.subscribe(this.player, (entity) => {
                if (entity instanceof Coin) {
                    //remove the coin from the game
                    //this.coins = this.coins.filter(c => c !== entity);
                    this.collisionEngine.unregister(entity);
                    entity.playCustomAnimation({onComplete: () => {
                            // Remove coin from game after animation completes
                            this.coins = this.coins.filter(c => c !== entity);
                        },
                    })
                    this.score += 1; // Increment score on collision with coin
                    this.sounds.coin?.play();
                }
                if (entity instanceof Enemy) {
                    this.score -= 10; // Decrement score on collision with enemy
                    // Calculate bounce direction and apply velocity-based bounce
                    const playerPosition = this.player.getPosition();
                    const enemyPosition = entity.getPosition();
                    const dx = playerPosition.x - enemyPosition.x;
                    const dy = playerPosition.y - enemyPosition.y;
                    const distance = Math.sqrt(dx * dx + dy * dy);
                    
                    this.handleStaticCollision(this.player, entity);

                    if (distance > 0) {
                        const bounceFactor = 2000; // Bounce velocity strength
                        const bounceVector = {
                            x: (dx / distance) * bounceFactor,
                            y: (dy / distance) * bounceFactor
                        };
                        this.player.applyBounce(bounceVector);
                    }
                }
                if (entity instanceof Platform) {
                    // Handle platform collision - stop player movement into platform
                    this.handleStaticCollision(this.player, entity);
                }
                if (entity instanceof FrozenClone) {
                    this.handleStaticCollision(this.player, entity);
                }
            });
        }

        // Reset game state
        this.isGameRunning = true;
    }

    /**
     * Clear all entities from the current level
     * @param {boolean} preserveClones - Whether to preserve existing frozen clones (default: false)
     */
    clearLevel(preserveClones = false) {
        // Unregister non-player entities from collision engine
        for (const coin of this.coins) {
            this.collisionEngine.unregister(coin);
        }
        for (const enemy of this.enemies) {
            this.collisionEngine.unregister(enemy);
        }
        for (const platform of this.platforms) {
            this.collisionEngine.unregister(platform);
        }
        
        // Only unregister and clear clones if not preserving them
        if (!preserveClones) {
            for (const frozenClone of this.frozenClones) {
                this.collisionEngine.unregister(frozenClone);
            }
        }
        
        this.score = 0;

        // Clear entity arrays (preserve clones if requested)
        this.coins = [];
        this.enemies = [];
        this.platforms = [];
        if (!preserveClones) {
            this.frozenClones = [];
        }
        this.anchors = []; // Clear anchors (they don't register with collision engine)
        this.messages = []; // Clear message tiles
        this.decals = []; // Clear decal tiles
        
        // Don't clear the collision engine completely - keep player registered
    }

    /**
     * Check if level is completed (all coins collected) and progress to next level or reset
     */
    checkLevelCompletion() {
        if (this.coins.length === 0 && this.totalCoins > 0 && !this.isLevelCompleting) {
            this.isLevelCompleting = true; // Prevent multiple triggers
            
            // Play level complete sound
            if (this.sounds.levelComplete) {
                this.sounds.levelComplete.play();
            }
            
            if (this.currentLevel < this.levelDefinitions.getMaxLevel()) {
                // Progress to next level
                console.log(`Level ${this.currentLevel} completed! Progressing to Level ${this.currentLevel + 1}...`);
                
                // Add a delay before progressing to let the player see completion
                setTimeout(() => {
                    this.nextLevel();
                }, this.levelCompleteDelay); 
            } else {
                // All levels completed - show end screen
                console.log('🎉 Congratulations! All levels completed! 🎉');
                
                // Log final statistics
                this.logFinalStats();
                
                // Transition to end screen
                this.gameState = 'END';
                this.stopMainMusic();
                this.playIntroMusic();
            }
        }
    }

    /**
     * Progress to the next level
     */
    nextLevel() {
        if (this.currentLevel < this.levelDefinitions.getMaxLevel()) {
            
            this.currentLevel++;
            console.log(`Starting Level ${this.currentLevel}...`);
            
            // Temporarily pause collision detection during level transition
            const wasRunning = this.isGameRunning;
            this.isGameRunning = false;
            
            // Load the new level without setting up collision handlers again, optionally preserving clones
            this.loadCurrentLevel(false);
            
            // Update total coins for the new level
            this.totalCoins = this.coins.length;
            
            // Reset completion flag
            this.isLevelCompleting = false;
            
            // Resume game after a brief pause
            setTimeout(() => {
                this.isGameRunning = wasRunning;
            }, 100); // 100ms pause
;
        }
    }

    /**
     * Go back to the previous level
     */
    previousLevel() {
        if (this.currentLevel > 1) {
            
            this.currentLevel--;
            console.log(`Going back to Level ${this.currentLevel}...`);
            
            // Track level backwards movement
            this.stats.levelBackwards++;
            
            // Temporarily pause collision detection during level transition
            const wasRunning = this.isGameRunning;
            this.isGameRunning = false;
            
            // Load the previous level without setting up collision handlers again
            this.loadCurrentLevel(false,true);
            
            // Update total coins for the new level
            this.totalCoins = this.coins.length;
            
            // Reset completion flag
            this.isLevelCompleting = false;
            
            // Resume game after a brief pause
            setTimeout(() => {
                this.isGameRunning = wasRunning;
            }, 100); // 100ms pause
        } else {
            console.log('Already at first level, cannot go back further');
        }
    }

    /**
     * Restart the game from level 1
     */
    restartGame() {
        console.log('Restarting game from Level 1...');
        
        // Reset to level 1
        this.currentLevel = 1;
        
        // Reset score
        this.score = 0;
        
        // Temporarily pause collision detection during restart
        const wasRunning = this.isGameRunning;
        this.isGameRunning = false;
        
        // Load level 1 without setting up collision handlers again
        this.loadCurrentLevel(false);
        
        // Update total coins for level 1
        this.totalCoins = this.coins.length;
        
        // Reset completion flag
        this.isLevelCompleting = false;
        
        // Resume game after a brief pause
        setTimeout(() => {
            this.isGameRunning = wasRunning;
        }, 100); // 100ms pause
        
        console.log(`Game restarted! Level 1 loaded, Score reset to: ${this.score}`);
    }

    /**
     * Reset the current level to its initial state
     */
    resetLevel() {
        console.log(`Resetting Level ${this.currentLevel}...`);
        //play sound effect
        this.sounds.restart?.play();
        // Track loop restart
        this.stats.loopRestarts++;

        // Start reset animation
        //this.levelResetAnimationIsPlaying = true;
        //this.levelResetAnimationStartTime = Date.now();
        
        // Temporarily pause collision detection to prevent jiggling during reset
        const wasRunning = this.isGameRunning;
        this.isGameRunning = false;
        
        

        // Reload the current level without setting up collision handlers again
        this.loadCurrentLevel(false,true);
        
        // Update total coins for the reset level
        this.totalCoins = this.coins.length;
        
        // Reset completion flag but keep current score and level
        this.isLevelCompleting = false;

        this.isGameRunning = wasRunning;
        this.levelResetAnimationIsPlaying = false;
        
        console.log(`Level ${this.currentLevel} reset! Player at: (${this.player.x}, ${this.player.y}), Score: ${this.score}`);
    }

    /**
     * Handle collision between player and platform
     * @param {Player} player - The player entity
     * @param {Platform} entity - The platform entity
     */
    handleStaticCollision(player, entity) {
        const playerBox = player.bounds.getCollisionBox(player);
        const platformBox = entity.bounds.getCollisionBox(entity);
        
        // Store original velocity for debugging
        const originalVelocityX = player.velocity.x;
        
        // Calculate overlap on each axis
        const overlapX = Math.min(playerBox.x + playerBox.width - platformBox.x, 
                                 platformBox.x + platformBox.width - playerBox.x);
        const overlapY = Math.min(playerBox.y + playerBox.height - platformBox.y, 
                                 platformBox.y + platformBox.height - playerBox.y);
        
        // Resolve collision on the axis with smallest overlap

        // Handle one-way platforms specially
        if (entity.collisionType === 'one-way-up') {
            // Trajectory-based collision: Check if player crossed the platform top between frames
            
            // Use stored previous player position (actual position from last frame)
            const prevPlayerBottom = this.previousPlayerPosition.y + player.bounds.offsetY + playerBox.height;
            const currentPlayerBottom = playerBox.y + playerBox.height;
            
            // Check horizontal overlap to ensure player is actually above the platform
            const horizontalOverlap = playerBox.x < platformBox.x + platformBox.width && 
                                    playerBox.x + playerBox.width > platformBox.x;
            
            // Only trigger collision if:
            // 1. Player has horizontal overlap with platform
            // 2. Player was above platform in previous frame
            // 3. Player's bottom edge has crossed or is now below platform top
            // 4. Player is moving downward
            if (horizontalOverlap && 
                prevPlayerBottom <= platformBox.y && 
                currentPlayerBottom >= platformBox.y && 
                player.velocity.y > 0) {
                
                // Player crossed the platform top while falling - land on platform
                player.y = platformBox.y - playerBox.height - player.bounds.offsetY;
                player.physics.onGround = true;
                player.velocity.y = 0;
            }
            // Ignore all other cases (moving up, jumping through, horizontal movement, etc.)
            return;
        }

        if (entity.collisionType === 'one-way-down') {
            // One-way platform that can only be collided with from below (jumping up into it)
            
            const prevPlayerTop = this.previousPlayerPosition.y + player.bounds.offsetY;
            const currentPlayerTop = playerBox.y;
            
            // Check horizontal overlap
            const horizontalOverlap = playerBox.x < platformBox.x + platformBox.width && 
                                    playerBox.x + playerBox.width > platformBox.x;
            
            // Only trigger collision if:
            // 1. Player has horizontal overlap with platform
            // 2. Player was below platform in previous frame
            // 3. Player's top edge has crossed or is now above platform bottom
            // 4. Player is moving upward
            if (horizontalOverlap && 
                prevPlayerTop >= platformBox.y + platformBox.height && 
                currentPlayerTop <= platformBox.y + platformBox.height && 
                player.velocity.y < 0) {
                
                // Player hit platform from below - stop upward movement
                player.y = platformBox.y + platformBox.height - player.bounds.offsetY;
                player.velocity.y = 0;
            }
            return;
        }

        if (entity.collisionType === 'one-way-left') {
            // One-way platform that can only be collided with from the left (moving right into it)
            
            const prevPlayerRight = this.previousPlayerPosition.x + player.bounds.offsetX + playerBox.width;
            const currentPlayerRight = playerBox.x + playerBox.width;
            
            // Check vertical overlap
            const verticalOverlap = playerBox.y < platformBox.y + platformBox.height && 
                                  playerBox.y + playerBox.height > platformBox.y;
            
            // Only trigger collision if:
            // 1. Player has vertical overlap with platform
            // 2. Player was to the left of platform in previous frame
            // 3. Player's right edge has crossed or is now past platform left
            // 4. Player is moving rightward
            if (verticalOverlap && 
                prevPlayerRight <= platformBox.x && 
                currentPlayerRight >= platformBox.x && 
                player.velocity.x > 0) {
                
                // Player hit platform from left - stop rightward movement
                player.x = platformBox.x - playerBox.width - player.bounds.offsetX;
                player.velocity.x = 0;
            }
            return;
        }

        if (entity.collisionType === 'one-way-right') {
            // One-way platform that can only be collided with from the right (moving left into it)
            
            const prevPlayerLeft = this.previousPlayerPosition.x + player.bounds.offsetX;
            const currentPlayerLeft = playerBox.x;
            
            // Check vertical overlap
            const verticalOverlap = playerBox.y < platformBox.y + platformBox.height && 
                                  playerBox.y + playerBox.height > platformBox.y;
            
            // Only trigger collision if:
            // 1. Player has vertical overlap with platform
            // 2. Player was to the right of platform in previous frame
            // 3. Player's left edge has crossed or is now past platform right
            // 4. Player is moving leftward
            if (verticalOverlap && 
                prevPlayerLeft >= platformBox.x + platformBox.width && 
                currentPlayerLeft <= platformBox.x + platformBox.width && 
                player.velocity.x < 0) {
                
                // Player hit platform from right - stop leftward movement
                player.x = platformBox.x + platformBox.width - player.bounds.offsetX;
                player.velocity.x = 0;
            }
            return;
        }

        if (overlapX < overlapY) {
            // Horizontal collision
            if (playerBox.x < platformBox.x) {
                // Player hit platform from the left
                if (entity.collisionType == 'solid' || entity.collisionType == 'numbered') {
                    player.x = platformBox.x - playerBox.width - player.bounds.offsetX;
                    player.velocity.x = 0; // Stop horizontal movement
                    
                }
            } else {
                // Player hit platform from the right
                if (entity.collisionType == 'solid' || entity.collisionType == 'numbered') {
                    player.x = platformBox.x + platformBox.width - player.bounds.offsetX;
                    player.velocity.x = 0; // Stop horizontal movement
                    
                }
            }
        } else {
            // Vertical collision
            if (playerBox.y < platformBox.y) {
                // Player hit platform from above (landing on top)
                if (entity.collisionType == 'solid' || entity.collisionType == 'numbered') {
                    player.y = platformBox.y - playerBox.height - player.bounds.offsetY;
                    player.physics.onGround = true; // Set grounded state using physics component
                    player.velocity.y = 0; // Stop vertical movement
                }
            } else {
                // Player hit platform from below (hitting ceiling)
                if (entity.collisionType == 'solid' || entity.collisionType == 'numbered') {
                    player.y = platformBox.y + platformBox.height - player.bounds.offsetY;
                    player.velocity.y = 0; // Stop vertical movement
                }


            }
        }
        
        // After collision resolution, check if velocity changed unexpectedly
        if (originalVelocityX !== 0 && player.velocity.x === 0) {
            console.log(`Velocity reset! Original: ${originalVelocityX}, New: ${player.velocity.x}`);
            console.log(`Platform type: ${entity.collisionType}, Player pos: (${player.x}, ${player.y})`);
            console.log(`Platform pos: (${entity.x}, ${entity.y})`);
        }
    }

    /**
     * Update game state
     * @param {number} deltaTime - Time elapsed since last frame in seconds
     */
    update(deltaTime) {
        if (!this.isGameRunning) return;
        
        // Store current player position before updating (for next frame's collision detection)
        this.previousPlayerPosition = { x: this.player.x, y: this.player.y };
        
        this.logPlayerIntersections();

        // Update cooldowns
        this.updateCooldowns(deltaTime);
        
        // Update player
        this.player.update(deltaTime);
        
        
        // Update all coins for animation
        for (const coin of this.coins) {
            coin.update(deltaTime);
        }
        
        // Update all enemies
        for (const enemy of this.enemies) {
            enemy.update(deltaTime);
        }
        
        // Update all frozen clones
        for (const frozenClone of this.frozenClones) {
            frozenClone.update(deltaTime);
        }
        
        // Check and remove numbered platforms based on score
        this.updateNumberedPlatforms();
        
        // Check collisions
        this.collisionEngine.checkCollisions();
        
        // Round player position to avoid fractional pixels after collision resolution
        this.player.roundPosition();
        
        // Check if level is completed (all coins collected)
        this.checkLevelCompletion();
    }

    /**
     * Check and remove numbered platforms based on current score
     */
    updateNumberedPlatforms() {
        const initialPlatformCount = this.platforms.length;
        
        // Remove platforms that should disappear based on score
        this.platforms = this.platforms.filter(platform => {
            if (platform.collisionType === 'numbered' && platform.requiredCoins !== null) {
                const shouldRemove = this.score >= platform.requiredCoins;
                if (shouldRemove) {
                    // Unregister from collision engine
                    this.collisionEngine.unregister(platform);
                    console.log(`Removed numbered platform (${platform.requiredCoins}) - player has ${this.score} coins`);
                }
                return !shouldRemove;
            }
            return true; // Keep all non-numbered platforms
        });
        
        // Log if any platforms were removed
        const removedCount = initialPlatformCount - this.platforms.length;
        if (removedCount > 0) {
            console.log(`Removed ${removedCount} numbered platforms`);
        }
    }

    /**
     * Update cooldown timers
     * @param {number} deltaTime - Time elapsed since last frame in seconds
     */
    updateCooldowns(deltaTime) {
        if (this.placeCooldown > 0) {
            this.placeCooldown -= deltaTime * 1000; // Convert to milliseconds
            if (this.placeCooldown < 0) {
                this.placeCooldown = 0;
            }
        }
    }

    /**
     * Apply input to player
     * @param {string} direction - Direction to move
     * @param {number} deltaTime - Time elapsed since last frame in seconds
     */
    applyPlayerInput(direction, deltaTime) {
        if (!this.isGameRunning) return;
        
        this.player.applyInput(direction, deltaTime);
    }

    /**
     * Handle place action with cooldown
     * @returns {boolean} Whether the action was successful
     */
    handlePlaceAction() {
        // Check if cooldown is active
        if (this.placeCooldown > 0) {
            //console.log(`Place action on cooldown. ${(this.placeCooldown / 1000).toFixed(1)}s remaining`);
            return false;
        }

        // Check if clone limit is reached (limit based on current level)
        const currentLevel = this.levelDefinitions.getLevel(this.currentLevel);
        const maxClones = currentLevel.maxClones || 0;
        if (this.frozenClones.length >= maxClones) {
            console.log(`Clone limit reached! Current clones: ${this.frozenClones.length}, Max allowed: ${maxClones}`);
            return false;
        }

        // Get player position
        const playerPosition = this.player.getPosition();
        
        // Set cooldown
        this.placeCooldown = this.placeCooldownTime;
        const playerCollisionBox = this.player.bounds.getCollisionBox(this.player);
        
        // Create frozen clone with destruction callback
        const frozenClone = new FrozenClone(
            Math.round(playerPosition.x), 
            Math.round(playerPosition.y), 
            this.player.width, 
            this.player.height,
            (clone) => this.removeFrozenClone(clone) // Destruction callback
        );
        //play clone sound
        this.sounds.clone?.play();
        frozenClone.boundsEnabled = false; 
        this.frozenClones.push(frozenClone);
        this.collisionEngine.register(frozenClone);
        
        // Track clone placement
        this.stats.frozenClonesPlaced++;
        
        setTimeout(() => {
            frozenClone.boundsEnabled = true; // Enable bounds after grace period
        }, 600); 

        return true;
    }

    /**
     * Remove a frozen clone from the game
     * @param {FrozenClone} clone - The clone to remove
     */
    removeFrozenClone(clone) {
        // Unregister from collision engine
        this.collisionEngine.unregister(clone);
        
        // Remove from frozen clones array
        this.frozenClones = this.frozenClones.filter(c => c !== clone);
        // Play destruction sound effect
        this.sounds.destroyClone?.play();
        
        // Track clone destruction
        this.stats.frozenClonesDestroyed++;
        
        console.log(`Frozen clone destroyed. Remaining clones: ${this.frozenClones.length}`);
    }

    /**
     * Remove the oldest frozen clone from the game
     */
    removeOldestFrozenClone() {
        if (this.frozenClones.length > 0) {
            const oldestClone = this.frozenClones[0]; // First clone in array is oldest
            
            // Play VFX animation before removing

            oldestClone.setAnimationEnabled(true, 3); // Play animation once
            
            // Update animation callback to handle removal after animation
            oldestClone.animationLoopCallback = () => {

                oldestClone.setAnimationEnabled(false);
                
                // Remove the clone after animation completes
                this.removeFrozenClone(oldestClone);
                console.log(`Oldest frozen clone removed with VFX. Remaining clones: ${this.frozenClones.length}`);
            };
            
            console.log(`Playing VFX animation for oldest clone removal...`);
        } else {
            console.log('No frozen clones to remove');
        }
    }

    /**
     * Get the player object
     * @returns {Player} Player instance
     */
    getPlayer() {
        return this.player;
    }

    getCoins() {
        return this.coins;
    }
    
    getTotalCoins() {
        return this.totalCoins;
    }

    getEnemies() {
        return this.enemies;
    }

    /**
     * Get all message tiles
     * @returns {Array} Array of message tile objects
     */
    getMessages() {
        return this.messages;
    }

    /**
     * Get all decal tiles
     * @returns {Array} Array of decal tile objects
     */
    getDecals() {
        return this.decals;
    }

    /**
     * Get all frozen clones
     * @returns {Array} Array of frozen clone objects
     */
    getFrozenClones() {
        return this.frozenClones;
    }

    /**
     * Update viewport bounds for culling based on camera offset
     * @param {number} cameraOffsetX - Camera X offset
     * @param {number} cameraOffsetY - Camera Y offset
     */
    updateViewport(cameraOffsetX, cameraOffsetY) {
        this.viewport.left = -cameraOffsetX - this.viewport.buffer;
        this.viewport.right = -cameraOffsetX + this.canvasWidth + this.viewport.buffer;
        this.viewport.top = -cameraOffsetY - this.viewport.buffer;
        this.viewport.bottom = -cameraOffsetY + this.canvasHeight + this.viewport.buffer;
    }

    /**
     * Get current viewport bounds for culling
     * @returns {Object} Viewport bounds {left, right, top, bottom, buffer}
     */
    getViewport() {
        return this.viewport;
    }

    /**
     * Check if an entity is within the viewport (for culling)
     * @param {Object} entity - Entity with x, y, width, height properties
     * @returns {boolean} True if entity intersects with viewport
     */
    isEntityInViewport(entity) {
        return (
            entity.x < this.viewport.right &&
            entity.x + entity.width > this.viewport.left &&
            entity.y < this.viewport.bottom &&
            entity.y + entity.height > this.viewport.top
        );
    }

    /**
     * Check and log if player is intersecting with any entities
     * @returns {Array} Array of entity types the player is intersecting with
     */
    logPlayerIntersections() {
        const intersections = [];
        const playerBox = this.player.bounds.getCollisionBox(this.player);

        // Check intersections with platforms
        for (const platform of this.platforms) {
            const platformBox = platform.bounds.getCollisionBox(platform);
            if (this.isBoxIntersecting(playerBox, platformBox)) {
                intersections.push('Platform');
            }
        }

        // Check intersections with enemies
        for (const enemy of this.enemies) {
            const enemyBox = enemy.bounds.getCollisionBox(enemy);
            if (this.isBoxIntersecting(playerBox, enemyBox)) {
                intersections.push('Enemy');
            }
        }

        // Check intersections with frozen clones
        for (const frozenClone of this.frozenClones) {
            if (!frozenClone.boundsEnabled) continue; // Skip if bounds are not enabled
            const cloneBox = frozenClone.bounds.getCollisionBox(frozenClone);
            if (this.isBoxIntersecting(playerBox, cloneBox)) {
                intersections.push('FrozenClone');
            }
        }

        // Log results
        if (intersections.length > 0) {
            console.log(`Player intersecting with: ${intersections.join(', ')}`);
            // move player toward the first anchor
            const firstAnchor = this.anchors[0];
            if (firstAnchor) {
                const dx = firstAnchor.x - this.player.x;
                const dy = firstAnchor.y - this.player.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                // Move player towards anchor if not already there
                if (distance > 0) {
                    const moveSpeed = 16; // Pixels per second
                    this.player.x += (dx / distance) * moveSpeed * (deltaTime / 1000);
                    this.player.y += (dy / distance) * moveSpeed * (deltaTime / 1000);
                }
            }
        } else {
            //console.log('Player not intersecting with any entities');
        }

        return intersections;
    }

    /**
     * Check if two bounding boxes are intersecting
     * @param {Object} box1 - First bounding box {x, y, width, height}
     * @param {Object} box2 - Second bounding box {x, y, width, height}
     * @returns {boolean} True if boxes intersect
     */
    isBoxIntersecting(box1, box2) {
        return box1.x < box2.x + box2.width &&
               box1.x + box1.width > box2.x &&
               box1.y < box2.y + box2.height &&
               box1.y + box1.height > box2.y;
    }

    /**
     * Get canvas dimensions
     * @returns {Object} Canvas dimensions
     */
    getCanvasDimensions() {
        return {
            width: this.canvasWidth,
            height: this.canvasHeight
        };
    }

    /**
     * Get current game score
     * @returns {number} Current score
     */
    getScore() {
        return this.score;
    }

    /**
     * Get all platforms
     * @returns {Array} Array of platform objects
     */
    getPlatforms() {
        return this.platforms;
    }

    /**
     * Get all anchors
     * @returns {Array} Array of anchor objects
     */
    getAnchors() {
        return this.anchors;
    }

    /**
     * Get current placement cooldown
     * @returns {number} Placement cooldown in milliseconds
     */
    getPlaceCooldown() {
        return this.placeCooldown;
    }

    /**
     * Get total placement cooldown time
     * @returns {number} Total placement cooldown time in milliseconds
     */
    getPlaceCooldownTime() {
        return this.placeCooldownTime;
    }

    /**
     * Get current clone limit (based on current level)
     * @returns {number} Maximum number of clones that can be placed
     */
    getCloneLimit() {
        const currentLevel = this.levelDefinitions.getLevel(this.currentLevel);
        return currentLevel.maxClones || 0;
    }

    /**
     * Get number of available clone slots
     * @returns {number} Number of additional clones that can be placed
     */
    getAvailableCloneSlots() {
        return Math.max(0, this.getCloneLimit() - this.frozenClones.length);
    }

    /**
     * Check if clone limit is reached
     * @returns {boolean} True if no more clones can be placed
     */
    isCloneLimitReached() {
        return this.frozenClones.length >= this.getCloneLimit();
    }

    /**
     * Get current level number
     * @returns {number} Current level number
     */
    getCurrentLevel() {
        return this.currentLevel;
    }

    /**
     * Get maximum level number
     * @returns {number} Maximum level number
     */
    getMaxLevel() {
        return this.levelDefinitions.getMaxLevel();
    }

    /**
     * Check if game is running
     * @returns {boolean} Game running state
     */
    isRunning() {
        return this.isGameRunning;
    }
    
    /**
     * Get current game state
     * @returns {string} Current game state ('TITLE', 'PLAYING', 'END')
     */
    getGameState() {
        return this.gameState;
    }
    
    /**
     * Start the game from title screen
     */
    startGame() {
        if (this.gameState === 'TITLE') {
            this.gameState = 'PLAYING';
            this.stopIntroMusic();
            this.playMainMusic();
            this.restartGame(); // Initialize the game
        }
    }
    
    /**
     * Return to title screen from end screen
     */
    returnToTitle() {
        this.gameState = 'TITLE';
        this.currentLevel = 1;
        this.isGameRunning = true;
        this.stopMainMusic();
        // Only start intro music if it's not already playing
        if (!this.music.intro || !this.music.intro.isPlaying()) {
            this.playIntroMusic();
        }
    }

    /**
     * Pause/Resume game
     */
    togglePause() {
        this.isGameRunning = !this.isGameRunning;
    }

    setLevelCompleteSound(sound) {
        this.sounds.levelComplete = sound;
    }
    setCoinSound(sound) {
        this.sounds.coin = sound;
    }
    setJumpSound(sound) {
        this.sounds.jump = sound;
    }
    setCloneSound(sound) {
        this.sounds.clone = sound;
    }
    setDestroyCloneSound(sound) {
        this.sounds.destroyClone = sound;
    }
    setRestartSound(sound) {
        this.sounds.restart = sound;
    }
    setMainMusic(sound) {
        this.music.main = sound;
    }
    
    setIntroMusic(sound) {
        this.music.intro = sound;
    }
    
    playIntroMusic() {
        if (this.music.intro && this.musicPlaying) {
            this.music.intro.loop();
            console.log('Intro music started');
        }
    }
    
    stopIntroMusic() {
        if (this.music.intro && this.music.intro.isPlaying()) {
            this.music.intro.stop();
            console.log('Intro music stopped');
        }
    }
    
    playMainMusic() {
        if (this.music.main && this.musicPlaying) {
            this.music.main.loop();
            console.log('Main music started');
        }
    }
    
    stopMainMusic() {
        if (this.music.main && this.music.main.isPlaying()) {
            this.music.main.stop();
            console.log('Main music stopped');
        }
    }
    
    toggleMusic() {
        this.musicPlaying = !this.musicPlaying;
        
        if (this.musicPlaying) {
            // Resume music based on current game state
            const gameState = this.getGameState();
            if (gameState === 'TITLE' || gameState === 'END') {
                this.playIntroMusic();
            } else if (gameState === 'PLAYING') {
                this.playMainMusic();
            }
            console.log('Music enabled');
        } else {
            // Pause all music
            if (this.music.main && this.music.main.isPlaying()) {
                this.music.main.pause();
            }
            if (this.music.intro && this.music.intro.isPlaying()) {
                this.music.intro.pause();
            }
            console.log('Music disabled');
        }
    }
    
    playSound(soundName) {
        if (this.sounds[soundName]) {
            this.sounds[soundName].play();
        } else {
            console.warn(`Sound ${soundName} not found!`);
        }
    }

    /**
     * Get statistics for UI display
     * @returns {Object} Statistics object with clone tracking data
     */
    getStats() {
        return { ...this.stats };
    }

    /**
     * Get level reset animation state
     * @returns {Object} Animation state with playing flag and progress
     */
    getLevelResetAnimationState() {
        if (!this.levelResetAnimationIsPlaying) {
            return { isPlaying: false, progress: 0 };
        }
        
        const elapsed = Date.now() - this.levelResetAnimationStartTime;
        const progress = Math.min(elapsed / this.levelResetAnimationDuration, 1.0);
        
        return {
            isPlaying: true,
            progress: progress,
            elapsed: elapsed,
            duration: this.levelResetAnimationDuration
        };
    }

    /**
     * Log final statistics when all levels completed
     */
    logFinalStats() {
        console.log('=== GAME COMPLETION STATISTICS ===');
        console.log(`Frozen Clones Placed: ${this.stats.frozenClonesPlaced}`);
        console.log(`Frozen Clones Destroyed: ${this.stats.frozenClonesDestroyed}`);
        console.log(`Loop Restarts: ${this.stats.loopRestarts}`);
        console.log(`Level Backwards: ${this.stats.levelBackwards}`);
        console.log('=====================================');
    }

}
